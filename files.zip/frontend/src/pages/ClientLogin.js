import React from "react";

function ClientLogin() {
  return (
    <div>
      <h2>Client Login</h2>
      <form>
        <input type="text" placeholder="Email" />
        <input type="password" placeholder="Password" />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default ClientLogin;