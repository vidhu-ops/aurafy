import React from "react";

function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome to the dashboard. Here you can manage your interactions.</p>
    </div>
  );
}

export default Dashboard;